// To parse this JSON data, do
//
//     final leaveApplyPojo = leaveApplyPojoFromJson(jsonString);

import 'dart:convert';

LeaveApplyPojo leaveApplyPojoFromJson(String str) => LeaveApplyPojo.fromJson(json.decode(str));

String leaveApplyPojoToJson(LeaveApplyPojo data) => json.encode(data.toJson());

class LeaveApplyPojo {
  LeaveApplyPojo({
    this.status,
    this.message,
  });

  int? status;
  String? message;

  factory LeaveApplyPojo.fromJson(Map<String, dynamic> json) => LeaveApplyPojo(
    status: json["status"],
    message: json["message"],
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
  };
}
