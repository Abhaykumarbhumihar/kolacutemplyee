import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:kolacut_employee/model/LoginPojo.dart';
import 'package:kolacut_employee/model/ProfilePojo.dart';

import '../services/ApiCall.dart';
import '../utils/CommomDialog.dart';
import '../utils/appconstant.dart';

class ProfileController extends GetxController {
  var profilePojo = ProfilePojo().obs;
  var lodaer = true;
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
    getProfile("PqtoOdpQ0SBVTMT0a15gnT7euR9x8fO6");
  }



//session_id:PqtoOdpQ0SBVTMT0a15gnT7euR9x8fO6
  void getProfile(session_id) async {
    Map map;
    map = {"session_id": "PqtoOdpQ0SBVTMT0a15gnT7euR9x8fO6"};
    try {
      CommonDialog.showLoading(title: "Please waitt...");
      final response =
      await APICall().registerUrse(map, AppConstant.GET_PROFILE);
      print(response);
      CommonDialog.hideLoading();
      profilePojo.value = profilePojoFromJson(response);
      if (profilePojo.value.message == "No Data found") {
        CommonDialog.showsnackbar("No Data found");
      } else {
        // Get.to(const VerifyOtpPage());
        update();
        lodaer = false;
      }
    } catch (error) {
      if (kDebugMode) {
        print(error);
      }
      CommonDialog.hideLoading();
    }
  }
}
