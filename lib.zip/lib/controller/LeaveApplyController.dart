import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:kolacut_employee/model/LeaveApplyPojo.dart';

import '../services/ApiCall.dart';
import '../utils/CommomDialog.dart';
import '../utils/appconstant.dart';

class LeaveApplyController extends GetxController {
  var leaveApplyPojo = LeaveApplyPojo().obs;
  var lodaer = true;

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
  }

//  session_id:PqtoOdpQ0SBVTMT0a15gnT7euR9x8fO6
// leave_date:2022-06-05
// holiday_type:partialy_off
// start_from:10:00
// end_from:01:00
// holiday_reason:urgent work at home

  void applyLeave(
      session_id, date, leavetype, starttime, endtime, reason) async {
    Map map;
    map = {
      "session_id": "PqtoOdpQ0SBVTMT0a15gnT7euR9x8fO6",
      "leave_date": date,
      "holiday_type": leavetype,
      "start_from": starttime,
      "end_from": endtime,
      "holiday_reason": reason
    };
    try {
      CommonDialog.showLoading(title: "Please waitt...");
      final response =
          await APICall().registerUrse(map, AppConstant.LEAVE_APPLY);
      print(response);
      CommonDialog.hideLoading();
      leaveApplyPojo.value = leaveApplyPojoFromJson(response);
      if (leaveApplyPojo.value.message == "No Data found") {
        CommonDialog.showsnackbar("No Data found");
      } else {
        // Get.to(const VerifyOtpPage());
        update();
        lodaer = false;
      }
    } catch (error) {
      if (kDebugMode) {
        print(error);
      }
      CommonDialog.hideLoading();
    }
  }
}
