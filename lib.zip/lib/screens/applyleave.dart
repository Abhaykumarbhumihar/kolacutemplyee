import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kolacut_employee/controller/LeaveApplyController.dart';
import 'package:kolacut_employee/utils/CommomDialog.dart';
import 'package:kolacut_employee/utils/Utils.dart';

class ApplyLeave extends StatefulWidget {
  const ApplyLeave({Key? key}) : super(key: key);

  @override
  State<ApplyLeave> createState() => _ApplyLeaveState();
}

class FruitsList {
  String name;
  int index;

  FruitsList({required this.name, required this.index});
}

class _ApplyLeaveState extends State<ApplyLeave> {
  LeaveApplyController leaveapplyController = Get.put(LeaveApplyController());
  TextEditingController ddController = TextEditingController();
  TextEditingController mmController = TextEditingController();
  TextEditingController yyyyController = TextEditingController();
  bool holidaytype = false;
  bool _value = false;
  int val = -1;

  // Default Radio Button Item
  String radioItem = 'Partial off';
  String holidayItem = 'Weekend';

  // Group Value for Radio Button.
  int id = 1;
  int holidayid = 1;
  TimeOfDay openingTime = TimeOfDay.now();
  TimeOfDay closingTime = TimeOfDay.now();
  var opent = "";
  var closet = "";
  List<FruitsList> typeofHolidayList = [
    FruitsList(
      index: 1,
      name: "Partial off ",
    ),
    FruitsList(
      index: 2,
      name: "Fully off",
    ),
  ];

  List<FruitsList> reasonOfHoliday = [
    FruitsList(
      index: 1,
      name: "Weekend ",
    ),
    FruitsList(
      index: 2,
      name: "National Holiday",
    ),
    FruitsList(
      index: 3,
      name: "Festival",
    ),
    FruitsList(
      index: 4,
      name: "Lockdown",
    ),
    FruitsList(
      index: 5,
      name: "Other",
    ),
  ];

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;
    return SafeArea(
        child: Container(
      width: width,
      height: height,
      child: Scaffold(
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(left: width * 0.06, top: 6.0),
                child: Text(
                  'Add a date',
                  style: TextStyle(
                      fontFamily: 'Poppins Regular',
                      color: Color(Utils.hexStringToHexInt('8D8D8D')),
                      fontSize: width * 0.04),
                ),
              ),
              SizedBox(
                height: 4.0,
              ),
              Container(
                margin: EdgeInsets.only(left: width * 0.05),
                child: Row(
                  children: <Widget>[
                    Utils.applyLeavdd(ddController, width, height),
                    SizedBox(
                      width: 3.0,
                    ),
                    Utils.applyLeavdd(mmController, width, height),
                    SizedBox(
                      width: 3.0,
                    ),
                    Utils.applyLeavdd(yyyyController, width, height),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: width * 0.06, top: 8.0),
                child: Text(
                  'Type of Holiday ',
                  style: TextStyle(
                      fontFamily: 'Poppins Regular',
                      color: Color(Utils.hexStringToHexInt('8D8D8D')),
                      fontSize: width * 0.04),
                ),
              ),
              Container(
                height: height * 0.1,
                width: width,
                child: Expanded(
                  child: Row(
                    children: typeofHolidayList
                        .map((data) => Expanded(
                              child: RadioListTile(
                                title: Text(
                                  "${data.name}",
                                  style: TextStyle(
                                      fontFamily: 'Poppins Regular',
                                      color: Color(
                                          Utils.hexStringToHexInt('8D8D8D')),
                                      fontSize: width * 0.03),
                                ),
                                groupValue: id,
                                value: data.index,
                                onChanged: (val) {
                                  setState(() {
                                    radioItem = data.name;
                                    id = data.index;
                                  });
                                },
                              ),
                            ))
                        .toList(),
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: width * 0.06, top: 8.0),
                child: Flexible(
                  child: Text(
                    'Store Operational Hours for Partial off ',
                    textAlign: TextAlign.start,
                    style: TextStyle(
                        fontFamily: 'Poppins Regular',
                        color: Color(Utils.hexStringToHexInt('8D8D8D')),
                        fontSize: width * 0.04),
                  ),
                ),
              ),
              SizedBox(
                height: 4.0,
              ),
              Row(
                children: <Widget>[
                  Container(
                    margin: EdgeInsets.only(
                        left: width * 0.06, right: width * 0.02),
                    child: Row(
                      children: <Widget>[
                        GestureDetector(
                          onTap: () {
                            _selectTime(context);
                          },
                          child: Container(
                            padding: EdgeInsets.all(width * 0.003),
                            alignment: Alignment.center,
                            width: width * 0.1 + width * 0.06,
                            height: height * 0.05,
                            margin: EdgeInsets.only(right: width * 0.01),
                            decoration: BoxDecoration(
                                color: Color(Utils.hexStringToHexInt('E5E5E5')),
                                borderRadius: BorderRadius.circular(4)),
                            child: Text(
                              "${openingTime.hour}:${openingTime.minute}",
                              style: TextStyle(
                                  fontSize: width * 0.02,
                                  color: Colors.black,
                                  fontFamily: 'Poppins Regular'),
                            ),
                          ),
                        ),
                        Column(
                          children: <Widget>[
                            Text(
                              'AM',
                              style: TextStyle(
                                  color: openingTime.period
                                              .toString()
                                              .split('.')[1] ==
                                          "am"
                                      ? Color(Utils.hexStringToHexInt('46D0D9'))
                                      : Colors.black,
                                  fontFamily: 'Poppins Regular',
                                  fontSize: width * 0.02),
                            ),
                            Text(
                              'PM',
                              style: TextStyle(
                                  color: openingTime.period
                                              .toString()
                                              .split('.')[1] ==
                                          "pm"
                                      ? Colors.blueAccent
                                      : Colors.black,
                                  fontFamily: 'Poppins Regular',
                                  fontSize: width * 0.02),
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    width: width * 0.1,
                    height: height * 0.02,
                    child: Divider(
                      thickness: 2,
                      color: Colors.black,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: width * 0.02),
                    child: Row(
                      children: <Widget>[
                        GestureDetector(
                          onTap: () {
                            _closingTime(context);
                          },
                          child: Container(
                            padding: EdgeInsets.all(width * 0.003),
                            alignment: Alignment.center,
                            width: width * 0.1 + width * 0.06,
                            height: height * 0.05,
                            margin: EdgeInsets.only(right: width * 0.01),
                            decoration: BoxDecoration(
                                color: Color(Utils.hexStringToHexInt('E5E5E5')),
                                borderRadius: BorderRadius.circular(4)),
                            child: Text(
                              "${closingTime.hour}:${closingTime.minute}",
                              style: TextStyle(
                                  fontSize: width * 0.02,
                                  color: Colors.black,
                                  fontFamily: 'Poppins Regular'),
                            ),
                          ),
                        ),
                        Column(
                          children: <Widget>[
                            Text(
                              'AM',
                              style: TextStyle(
                                  color: closingTime.period
                                              .toString()
                                              .split('.')[1] ==
                                          "am"
                                      ? Color(Utils.hexStringToHexInt('46D0D9'))
                                      : Colors.black,
                                  fontFamily: 'Poppins Regular',
                                  fontSize: width * 0.02),
                            ),
                            Text(
                              'PM',
                              style: TextStyle(
                                  color: closingTime.period
                                              .toString()
                                              .split('.')[1] ==
                                          "pm"
                                      ? Colors.blueAccent
                                      : Colors.black,
                                  fontFamily: 'Poppins Regular',
                                  fontSize: width * 0.02),
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                ],
              ),
              Container(
                margin: EdgeInsets.only(left: width * 0.08, top: 8.0),
                child: Text(
                  'Reason of the Holiday  ',
                  style: TextStyle(
                      fontFamily: 'Poppins Regular',
                      color: Color(Utils.hexStringToHexInt('8D8D8D')),
                      fontSize: width * 0.04),
                ),
              ),
              Container(
                height: height * 0.3,
                child: Expanded(
                  child: Column(
                    children: reasonOfHoliday
                        .map((data) => Expanded(
                              child: RadioListTile(
                                title: Text(
                                  "${data.name}",
                                  style: TextStyle(
                                      fontFamily: 'Poppins Regular',
                                      color: Color(
                                          Utils.hexStringToHexInt('8D8D8D')),
                                      fontSize: width * 0.03),
                                ),
                                groupValue: holidayid,
                                value: data.index,
                                onChanged: (val) {
                                  setState(() {
                                    radioItem = data.name;
                                    holidayid = data.index;
                                  });
                                },
                              ),
                            ))
                        .toList(),
                  ),
                ),
              ),
              SizedBox(
                height: height * 0.04,
              ),
              GestureDetector(
                onTap: () {
                  applyLeave();
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: width * 0.5,
                      height: height * 0.1,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(width * 0.05),
                          color: Color(Utils.hexStringToHexInt('4285F4'))),
                      child: Center(
                        child: Text(
                          'SAVE',
                          style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'Poppins Semibold',
                              fontSize: width * 0.04),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 15,
              )
            ],
          ),
        ),
      ),
    ));
  }

  _selectTime(BuildContext context) async {
    final TimeOfDay? timeOfDay = await showTimePicker(
      context: context,
      initialTime: openingTime,
      initialEntryMode: TimePickerEntryMode.dial,
    );
    if (timeOfDay != null && timeOfDay != openingTime) {
      setState(() {
        openingTime = timeOfDay;
        opent =
            "${openingTime.hour}:${openingTime.minute}:${openingTime.period.toString().split('.')[1].toString()}";
      });
    }
  }

  _closingTime(BuildContext context) async {
    final TimeOfDay? timeOfDay = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
      initialEntryMode: TimePickerEntryMode.dial,
    );
    if (timeOfDay != null && timeOfDay != closingTime) {
      setState(() {
        closingTime = timeOfDay;
        closet =
            "${closingTime.hour}:${closingTime.minute}:${closingTime.period.toString().split('.')[1].toString()}";
      });
    }
  }

  void applyLeave() {
    if (ddController.text.toString() == "" ||
        mmController.text.toString() == "" ||
        yyyyController.text.toString() == "") {
      CommonDialog.showsnackbar("Please Enter dd mm yyyy");
    } else {
      var date =  yyyyController.text.toString() +
          "-" +
          mmController.text.toString() +
          "-" +
          yyyyController.text.toString();
      print(ddController.text.toString());
      print(mmController.text.toString());
      print(yyyyController.text.toString());
      print(openingTime.toString());

      print(
          "${openingTime.hour}:${openingTime.minute}  ${openingTime.period.toString().split('.')[1]}");
      var start =
          "${openingTime.hour}:${openingTime.minute}  ${openingTime.period.toString().split('.')[1]}";
      var close =
          "${closingTime.hour}:${closingTime.minute}:${closingTime.period.toString().split('.')[1].toString()}";
      print(radioItem + "  " + id.toString());

      print(holidayItem + "  " + holidayid.toString());
      //"session_id": "PqtoOdpQ0SBVTMT0a15gnT7euR9x8fO6",
      leaveapplyController.applyLeave("PqtoOdpQ0SBVTMT0a15gnT7euR9x8fO6", date,
          radioItem, start, close, holidayItem);
    }
  }
}
