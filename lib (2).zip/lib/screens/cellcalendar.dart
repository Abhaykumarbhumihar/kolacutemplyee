import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cell_calendar/cell_calendar.dart';
import '../controller/LeaveApplyController.dart';
import 'package:get/get.dart';

class MyHomePage extends StatelessWidget {
  MyHomePage({Key? key}) : super(key: key);
  String title = "";



  LeaveApplyController leaveapplyController = Get.put(LeaveApplyController());

  @override
  Widget build(BuildContext context) {

    final cellCalendarPageController = CellCalendarPageController();
    //DateFormat.MEd().format(date)

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: GetBuilder<LeaveApplyController>(builder: (leaveapplyController) {
        if (leaveapplyController.lodaer.isTrue) {
          return Container();
        } else {

            final today = DateTime.now();
            List<CalendarEvent>sampleEvents=[];
            leaveapplyController.leaveApplyPojo.value.data!.forEach((element) {
              sampleEvents.add(CalendarEvent(
                  eventName:element.holidayType.toString(),
                  eventDate: element!.calenderDate!,
                  eventBackgroundColor: Colors.black));
            });
            // final sampleEvents = [
            //   CalendarEvent(
            //       eventName: "New iPhone",
            //       eventDate: today.add(Duration(days: -42)),
            //       eventBackgroundColor: Colors.black),
            //
            //   CalendarEvent(
            //       eventName: "Writijkjkjkjng test",
            //       eventDate: DateTime.parse('2022-07-25'),
            //       eventBackgroundColor: Colors.deepOrange),
            //   CalendarEvent(
            //       eventName: "Writijkjkjkjng test",
            //       eventDate: DateTime.parse('2022-07-26'),
            //       eventBackgroundColor: Colors.deepOrange),
            //   CalendarEvent(
            //       eventName: "Writijkjkjkjng test",
            //       eventDate: DateTime.parse('2022-07-27'),
            //       eventBackgroundColor: Colors.deepOrange),
            //   // CalendarEvent(
            //   //     eventName: "Play soccer",
            //   //     eventDate: today.add(Duration(days: -7)),
            //   //     eventBackgroundColor: Colors.greenAccent),
            //   // CalendarEvent(
            //   //     eventName: "Learn about history",
            //   //     eventDate: today.add(Duration(days: -7))),
            //   // CalendarEvent(
            //   //     eventName: "Buy new keyboard",
            //   //     eventDate: today.add(Duration(days: -7))),
            //   // CalendarEvent(
            //   //     eventName: "Walk around the park",
            //   //     eventDate: today.add(Duration(days: -7)),
            //   //     eventBackgroundColor: Colors.deepOrange),
            //   // CalendarEvent(
            //   //     eventName: "Buy a present for Rebecca",
            //   //     eventDate: today.add(Duration(days: -7)),
            //   //     eventBackgroundColor: Colors.pink),
            //   // CalendarEvent(
            //   //     eventName: "Firebase", eventDate: today.add(Duration(days: -7))),
            //   // CalendarEvent(eventName: "Task Deadline", eventDate: today),
            //   // CalendarEvent(
            //   //     eventName: "Jon's Birthday",
            //   //     eventDate: today.add(Duration(days: 3)),
            //   //     eventBackgroundColor: Colors.green),
            //   // CalendarEvent(
            //   //     eventName: "Date with Rebecca",
            //   //     eventDate: today.add(Duration(days: 7)),
            //   //     eventBackgroundColor: Colors.pink),
            //   // CalendarEvent(
            //   //     eventName: "Start to study Spanish",
            //   //     eventDate: today.add(Duration(days: 13))),
            //   // CalendarEvent(
            //   //     eventName: "Have lunch with Mike",
            //   //     eventDate: today.add(Duration(days: 13)),
            //   //     eventBackgroundColor: Colors.green),
            //   // CalendarEvent(
            //   //     eventName: "Buy new Play Station software",
            //   //     eventDate: today.add(Duration(days: 13)),
            //   //     eventBackgroundColor: Colors.indigoAccent),
            //   // CalendarEvent(
            //   //     eventName: "Update my flutter package",
            //   //     eventDate: today.add(Duration(days: 13))),
            //   // CalendarEvent(
            //   //     eventName: "Watch movies in my house",
            //   //     eventDate: today.add(Duration(days: 21))),
            //   // CalendarEvent(
            //   //     eventName: "Medical Checkup",
            //   //     eventDate: today.add(Duration(days: 30)),
            //   //     eventBackgroundColor: Colors.red),
            //   // CalendarEvent(
            //   //     eventName: "Gym",
            //   //     eventDate: today.add(Duration(days: 42)),
            //   //     eventBackgroundColor: Colors.indigoAccent),
            // ];


          //final _sampleEvents = sampleEvents();

        return
          CellCalendar(
            cellCalendarPageController: cellCalendarPageController,
            events: sampleEvents,
            daysOfTheWeekBuilder: (dayIndex) {
              final labels = ["S", "M", "T", "W", "T", "F", "S"];
              return Padding(
                padding: const EdgeInsets.only(bottom: 4.0),
                child: Text(
                  labels[dayIndex],
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              );
            },
            monthYearLabelBuilder: (datetime) {
              final year = datetime!.year.toString();
              final month = datetime.month.monthName;
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    const SizedBox(width: 16),
                    Text(
                      "$month  $year",
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      padding: EdgeInsets.zero,
                      icon: Icon(Icons.calendar_today),
                      onPressed: () {
                        cellCalendarPageController.animateToDate(
                          DateTime.now(),
                          curve: Curves.linear,
                          duration: Duration(milliseconds: 300),
                        );
                      },
                    )
                  ],
                ),
              );
            },

            onPageChanged: (firstDate, lastDate) {
              /// Called when the page was changed
              /// Fetch additional events by using the range between [firstDate] and [lastDate] if you want
            },
          );
        }
      }),
    );
  }
}
