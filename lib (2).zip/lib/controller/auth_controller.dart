import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:kolacut_employee/model/LoginPojo.dart';
import 'package:kolacut_employee/model/ProfilePojo.dart';

import '../services/ApiCall.dart';
import '../utils/CommomDialog.dart';
import '../utils/appconstant.dart';

class AuthController extends GetxController {
  var loginPojo = LoginPojo().obs;
  var profilePojo = ProfilePojo().obs;

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
  }

  //email:ajay78@gmail.com
  // password:12345678
  // device_token:123456
  // device_type:android

  void login(email, password) async {
    Map map;
    map = {
      "email": email,
      "password": password,
      "device_token": "SDF SDF SDF SDF SD F",
      "device_type": "android"
    };
    try {
      CommonDialog.showLoading(title: "Please waitt...");
      final response = await APICall().registerUrse(map, AppConstant.LOGIN);
      print(response);
      CommonDialog.hideLoading();
      loginPojo.value = loginPojoFromJson(response);
      if (loginPojo.value.message == "No Data found") {
        CommonDialog.showsnackbar("No Data found");
      } else {
        // Get.to(const VerifyOtpPage());
      }
    } catch (error) {
      if (kDebugMode) {
        print(error);
      }
      CommonDialog.hideLoading();
    }
  }

//session_id:PqtoOdpQ0SBVTMT0a15gnT7euR9x8fO6
  void getProfile(session_id) async {
    Map map;
    map = {"session_id": "PqtoOdpQ0SBVTMT0a15gnT7euR9x8fO6"};
    try {
      CommonDialog.showLoading(title: "Please waitt...");
      final response =
          await APICall().registerUrse(map, AppConstant.GET_PROFILE);
      print(response);
      CommonDialog.hideLoading();
      profilePojo.value = profilePojoFromJson(response);
      if (loginPojo.value.message == "No Data found") {
        CommonDialog.showsnackbar("No Data found");
      } else {
        // Get.to(const VerifyOtpPage());
      }
    } catch (error) {
      if (kDebugMode) {
        print(error);
      }
      CommonDialog.hideLoading();
    }
  }
}
