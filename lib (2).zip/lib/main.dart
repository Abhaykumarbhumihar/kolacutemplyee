import 'package:cell_calendar/cell_calendar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kolacut_employee/screens/homebottombar.dart';
import 'package:kolacut_employee/screens/login.dart';

import 'screens/cellcalendar.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(debugShowCheckedModeBanner: false,
        home: LoginPage());
  }
}