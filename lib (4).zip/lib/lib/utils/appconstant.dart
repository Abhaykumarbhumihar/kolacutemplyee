 class AppConstant{
   static const String BASE_URL = "http://kolacut.kvpscampuscare.com/";
   static const String SEND_OTP="public/api/login";
   static const String VERIFY_OTP="public/api/verify-otp";
   static const String LOGIN="public/api/employee-login";
   static const String GET_PROFILE="public/api/employee-detail";
   static const String LEAVE_APPLY="public/api/add-leave";
   static const String LEAVE_MANAGEMENT="public/api/leave-management";
   static const String GET_ALL_BOOKING="public/api/bookings";
   static const String ACCEPT_BOOKING="public/api/accept-booking-delivery";
}